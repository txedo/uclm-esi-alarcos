#ifndef __gluegen_types_h
#define __gluegen_types_h

#ifdef __GLUEGEN__
    #error "This file is not intended to be used for GlueGen code generation, use the gluegen/make/stub_includes/gluegen variation instead!"
#endif

#include <gluegen_stdint.h>
#include <gluegen_stddef.h>

#endif /* __gluegen_types_h */

