#! /bin/sh

sh make-cdc-es1.sh jar
sh make-jar.sh 
cp -v ragdoll.jar /jordan/data/packs/sun/mobile/apx2500.phone_image
